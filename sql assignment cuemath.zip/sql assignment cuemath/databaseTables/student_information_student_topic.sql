-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: student_information
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student_topic`
--

DROP TABLE IF EXISTS `student_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_topic` (
  `student_id` varchar(100) DEFAULT NULL,
  `Topic_id` varchar(100) DEFAULT NULL,
  `test_cleared` tinyint(1) DEFAULT NULL,
  `percentage_marks` bigint DEFAULT NULL,
  `test_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_topic`
--

LOCK TABLES `student_topic` WRITE;
/*!40000 ALTER TABLE `student_topic` DISABLE KEYS */;
INSERT INTO `student_topic` VALUES ('6','51',1,61,'2018-05-06'),('5','50',1,71,'2017-07-15'),('7','52',0,21,'2017-09-14'),('8','57',1,91,'2018-10-16'),('9','50',0,11,'2019-07-15'),('10','53',0,5,'2019-09-12'),('11','51',1,61,'2017-07-18'),('12','50',1,51,'2018-05-17'),('13','52',0,30,'2017-08-18'),('14','57',0,9,'2019-09-16'),('15','52',1,90,'2018-02-12'),('16','56',1,78,'2017-06-13'),('17','53',1,66,'2019-07-23'),('6','57',1,81,'2018-06-05'),('7','53',1,77,'2017-10-06'),('13','53',1,67,'2017-09-13'),('14','51',1,57,'2019-10-14'),('15','53',0,23,'2018-03-23'),('16','50',1,86,'2017-07-09'),('17','57',1,89,'2018-03-11'),('11','57',1,56,'2017-09-14'),('12','56',0,33,'2018-06-15'),('9','56',1,99,'2019-08-12'),('8','51',1,50,'2018-11-05'),('10','52',0,10,'2019-10-09'),('5','56',1,98,'2017-10-07');
/*!40000 ALTER TABLE `student_topic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  7:36:18
